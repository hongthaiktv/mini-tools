bash "$HOME/bin/termux-file-editor"

