export ANDROID_HOME=/data/data/com.termux/files/home/asdk
export PATH="$HOME/.local/gradle/gradle-8.7/bin:$PATH"
export ANDROID_AAPT2_EXE=/data/data/com.termux/files/usr/bin/aapt2
bash "$HOME/bin/termux-file-editor"

